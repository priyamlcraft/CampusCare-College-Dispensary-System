CampusCare - Manual Frontend Backup

This archive contains the separately preserved manual frontend backup files.
The main React + Vite application source is provided in CampusCare_Frontend.zip.
This backup is for reference and is not the active frontend folder used by the main application.
