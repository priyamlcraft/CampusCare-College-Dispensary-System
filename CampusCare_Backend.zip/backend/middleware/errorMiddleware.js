
const notFound = (req, res, next) => {
  const error = new Error(
    `Route Not Found - ${req.originalUrl}`
  );

  res.status(404);
  next(error);
};

const errorHandler = (error, req, res, next) => {
  const statusCode =
    res.statusCode === 200 ? 500 : res.statusCode;

  res.status(statusCode).json({
    success: false,
    message: error.message || "Internal Server Error",
    stack:
      process.env.NODE_ENV === "development"
        ? error.stack
        : undefined
  });
};

module.exports = {
  notFound,
  errorHandler
};
