
const express = require("express");
const cors = require("cors");
const dotenv = require("dotenv");

dotenv.config();

const connectDB = require("./config/db");

// Import Routes
const studentRoutes = require("./routes/studentRoutes");
const visitRoutes = require("./routes/visitRoutes");
const medicineRoutes = require("./routes/medicineRoutes");
const distributionRoutes = require("./routes/distributionRoutes");
const emergencyRoutes = require("./routes/emergencyRoutes");
const reportsRoutes = require("./routes/reportsRoutes");
const adminRoutes = require("./routes/adminRoutes");

// Import Error Middleware
const {
  notFound,
  errorHandler
} = require("./middleware/errorMiddleware");

const app = express();

// Connect MongoDB
connectDB();

// Middleware
app.use(cors({
  origin: ["http://localhost:5173", "http://localhost:5174"]
}));

app.use(express.json());

// Home Route
app.get("/", (req, res) => {
  res.status(200).json({
    success: true,
    message: "CampusCare Backend is Running!"
  });
});

// Health Check Route
app.get("/api/health", (req, res) => {
  res.status(200).json({
    success: true,
    message: "CampusCare API is healthy"
  });
});

// API Routes
app.use("/api/students", studentRoutes);
app.use("/api/visits", visitRoutes);
app.use("/api/medicines", medicineRoutes);
app.use("/api/distributions", distributionRoutes);
app.use("/api/emergencies", emergencyRoutes);
app.use("/api/reports", reportsRoutes);
app.use("/api/admin", adminRoutes);

// Error Handling
app.use(notFound);
app.use(errorHandler);

// Server Configuration
const PORT = process.env.PORT || 5000;

app.listen(PORT, () => {
  console.log(`CampusCare Backend running on port ${PORT}`);
});
